

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Recipient</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Upload</li>
                </ol>
                
                
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="container">
                            <div class="row">
                              <div class="col-sm-12">
                                <div class="sender-account-box">
                                  
                                  <form name="frmAddSMTP" method="POST" action="<?php echo e(route('recipients-upload')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                      <div class="col-sm-12">
                                        <div class="form-group">
                                          <label for="recipient_list_name">Recipients Group Name</label>
                                          <input 
                                              type="text" 
                                              class="form-control <?php $__errorArgs = ['recipient_list_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="recipient_list_name" 
                                              name="recipient_list_name" 
                                              aria-describedby="recipient_list_name" 
                                              placeholder="Enter Group Name"
                                              value="<?php echo e(old('recipient_list_name')); ?>"
                                          >
                                          <?php $__errorArgs = ['recipient_list_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="alert alert-danger"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                          <label for="recipient_list">Recipients List</label>
                                          <input 
                                                type="file" class="form-control <?php $__errorArgs = ['recipient_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="recipient_list" name="recipient_list" 
                                                aria-describedby="recipient_list"
                                          >
                                          <?php $__errorArgs = ['recipient_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                       
                                      </div>
                                      
                                   
                                    
                                     
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success" id="btnSaveSmtp">Update</button>
                                  </form>
                                </div>
                                <div class="alert smtp-test-response" style="display: none;">
                                </div>
                                <?php if(session()->has('message')): ?>
                                    <div class="alert <?php echo e(session()->get('classes')); ?>">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                    <div class="alert <?php echo e(session()->get('file')); ?>">
                                        <?php echo e(session()->get('file')); ?>

                                    </div>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Your Website 2022</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\email-demo\resources\views/user/recipient/add-new.blade.php ENDPATH**/ ?>