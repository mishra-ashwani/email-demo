

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Prepare Email</h1>
                <input type="hidden" name="template_body" class="template_body" value="<?php echo e($template_body); ?>">
                <input type="hidden" name="email_subject" class="email_subject" value="<?php echo e($email_subject); ?>">
                <button class="btnSendEmail" type="button">Send Email</button>
                <div class="container">
                    <div class="row">

                      <div class="col-sm-12">

                        <div class="smtp-list-box">
                          <h3>SMTP List</h3>
                          <?php $__currentLoopData = $smtps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smtp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="smtps[]" value="<?php echo e($smtp['id']); ?>" checked disabled>
                                <label class="form-check-label"><?php echo e($smtp['account_name']); ?></label>
                              </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="recipients-list-box">
                          <h3>Recipients List</h3>
                          <table class="table" id="datatablesSimple">
                            <thead class="thead-dark">
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">Recipient Email</th>
                                <th scope="col">Sender Email</th>
                                <th scope="col">Status</th>
                              <th scope="col">Comment</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php ($count=1); ?>
                              <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="row_<?php echo e($count); ?>">
                                  <th scope="row"><?php echo e($count); ?></th>
                                  <td class="recipient_<?php echo e($count); ?>"><?php echo e($recipient[0]); ?></td>
                                  <td class="sender_<?php echo e($count); ?>"></td>
                                  <td class="status_<?php echo e($count); ?>"></td>
                                  <td class="comment_<?php echo e($count); ?>"></td>
                                </tr>
                                <?php ($count++); ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
                            </tbody>
                          </table>
                          <input type="hidden" name="count" class="count" value="<?php echo e($count-1); ?>">
                  
                        </div>



                      </div>
                    </div>
                  </div>
                </div>
                    
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Your Website 2022</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/tinymce/tinymce.min.js')); ?>"></script>
<script>
  tinymce.init({
      selector: "textarea#template_body",
      plugins: "code",
      toolbar: "undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link code image_upload",
      menubar:false,
      statusbar: false,
      content_style: ".mce-content-body {font-size:15px;font-family:Arial,sans-serif;}",
      height: 400,
      relative_urls : false,
      remove_script_host : false,
      document_base_url : config.APP_URL,
      setup: function(ed) {
          
          var fileInput = $('<input id="tinymce-uploader" type="file" name="pic" accept="image/*" style="display:none">');
          $(ed.getElement()).parent().append(fileInput);
          
          fileInput.on("change",function(){           
              var file = this.files[0];
              var reader = new FileReader();          
              var formData = new FormData();
              var files = file;
              formData.append("file",files);
              formData.append('filetype', 'image');               
              jQuery.ajax({
                  url: "/service/template/upload-image",
                  type: "post",
                  data: formData,
                  contentType: false,
                  processData: false,
                  async: false,
                  success: function(response){
                      var fileName = response.path;
                      if(fileName) {
                          ed.insertContent('<img src="'+fileName+'"/>');
                      }
                  }
              });     
              reader.readAsDataURL(file);  
          });     
          
          ed.ui.registry.addButton('image_upload', {
              tooltip: 'Upload Image',
              icon: 'image',
              onAction: function () {
                  fileInput.trigger('click');
              }
          });
      }
  });

  

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\email-demo\resources\views/user/email/prepare.blade.php ENDPATH**/ ?>