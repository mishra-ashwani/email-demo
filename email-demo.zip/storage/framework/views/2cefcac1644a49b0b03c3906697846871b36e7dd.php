

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Dashboard</h1>
                
                <button type="button" name="btnTestAllSmtp" class="btnTestAllSmtp">Test SMTP</button>
                
                
                <div class="card mb-4 smtp-list-test">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        SMTP List
                    </div>
                    <div class="card-body">
                    
                        <table id="tblSmtpList">
                            <thead>
                                <tr>
                                    <th>Account Name</th>
                                    <th>From Name</th>
                                    <th>From Email</th>
                                    <th>Reply Email</th>
                                    <th>Server</th>
                                    <th>Port</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $smtps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smtp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="smtp_row_<?php echo e($smtp->id); ?>" data-smtp="<?php echo e($smtp->id); ?>">
                                    <td><?php echo e($smtp->account_name); ?></td>
                                    <td><?php echo e($smtp->from_name); ?></td>
                                    <td><?php echo e($smtp->from_email); ?></td>
                                    <td><?php echo e($smtp->reply_email); ?></td>
                                    <td><?php echo e($smtp->server); ?></td>
                                    <td><?php echo e($smtp->port); ?></td>
                                    <td><a href="<?php echo e(route('edit-smtp',['id'=>$smtp->id])); ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>  <button type="button" class="btnDeleteSmtp" data-id="<?php echo e($smtp->id); ?>" name="btnDeleteSmtp"><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Account Name</th>
                                    <th>From Name</th>
                                    <th>From Email</th>
                                    <th>Reply Email</th>
                                    <th>Server</th>
                                    <th>Port</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Your Website 2022</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\email-demo\resources\views/user/smtp/list-all.blade.php ENDPATH**/ ?>