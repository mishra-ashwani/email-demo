

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Create Email</h1>
                
                
                
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="container">
                            <div class="row">
                              <div class="col-sm-12">
                                <div class="sender-account-box">
                                  
                                  <form name="frmSendEmail" id="frmSendEmail" method="POST" action="<?php echo e(route('prepare-email')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                      <div class="col-sm-6">
                                        <div class="form-group">
                                          <label for="recipient_list">Recipients</label>
                                          <select name="recipient_list" class="recipient_list form-control" id="recipient_list">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $recipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($recipient->id); ?>"><?php echo e($recipient->recipient_list_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <?php $__errorArgs = ['recipient_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <div class="alert alert-danger"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>       
                                        <div class="form-group">
                                          <label for="email_subject">Email Subject</label>
                                          <input 
                                              type="text" class="form-control" 
                                              id="email_subject" name="email_subject" 
                                              aria-describedby="email_subject" placeholder="Email Subject"
                                              value="<?php echo e(old('email_subject')); ?>"
                                          >
                                          <?php $__errorArgs = ['email_subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>                                                                           
                                      </div>

                                      <div class="col-sm-6">
                                        <div class="form-group">
                                          <label for="email_subject">Choose SMTP</label>
                                          <?php $__currentLoopData = $smtps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smtp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              
                                              <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                  <div class="input-group-text">
                                                    <input type="checkbox" aria-label="Checkbox for following text input" name="smtps[]" value="<?php echo e($smtp->id); ?>"  <?php echo e((is_array(old('smtps')) and in_array($smtp->id, old('smtps'))) ? ' checked' : ''); ?>>
                                                  </div>
                                                </div>
                                                <label for="email_subject"><?php echo e($smtp->account_name); ?></label>
                                              </div>

                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                              <?php $__errorArgs = ['smtps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <div class="alert alert-danger"><?php echo e($message); ?></div>
                                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                      </div>

                                      <div class="col-sm-12">
                                        <div class="form-group">
                                          <label for="template_body">Email Template</label>
                                          <textarea name="template_body" id="template_body"><?php echo e(old('template_body')); ?></textarea>
                                          <?php $__errorArgs = ['template_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                      </div>
                                                                          
                                    </div>
                                    
                                    
                                    <button type="submit" class="btn btn-success" id="btnSendEmail" name="btnSendEmail">Send</button>
                                  </form>
                                </div>
                                <div class="alert smtp-test-response" style="display: none;">
                                </div>
                                <?php if(session()->has('message')): ?>
                                    <div class="alert <?php echo e(session()->get('classes')); ?>">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Your Website 2022</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="<?php echo e(asset('assets/js/tinymce/tinymce.min.js')); ?>"></script>
<script>
  tinymce.init({
      selector: "textarea#template_body",
      plugins: "code",
      toolbar: "undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link code image_upload",
      menubar:false,
      statusbar: false,
      content_style: ".mce-content-body {font-size:15px;font-family:Arial,sans-serif;}",
      height: 400,
      relative_urls : false,
      remove_script_host : false,
      document_base_url : config.APP_URL,
      setup: function(ed) {
          
          var fileInput = $('<input id="tinymce-uploader" type="file" name="pic" accept="image/*" style="display:none">');
          $(ed.getElement()).parent().append(fileInput);
          
          fileInput.on("change",function(){           
              var file = this.files[0];
              var reader = new FileReader();          
              var formData = new FormData();
              var files = file;
              formData.append("file",files);
              formData.append('filetype', 'image');               
              jQuery.ajax({
                  url: "/service/template/upload-image",
                  type: "post",
                  data: formData,
                  contentType: false,
                  processData: false,
                  async: false,
                  success: function(response){
                      var fileName = response.path;
                      if(fileName) {
                          ed.insertContent('<img src="'+fileName+'"/>');
                      }
                  }
              });     
              reader.readAsDataURL(file);  
          });     
          
          ed.ui.registry.addButton('image_upload', {
              tooltip: 'Upload Image',
              icon: 'image',
              onAction: function () {
                  fileInput.trigger('click');
              }
          });
      }
  });

  

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\email-demo\resources\views/user/email/create.blade.php ENDPATH**/ ?>